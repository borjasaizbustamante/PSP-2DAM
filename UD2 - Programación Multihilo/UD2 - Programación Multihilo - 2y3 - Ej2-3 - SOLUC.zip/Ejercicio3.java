package zPSPHilos.ejercicios;

/**
 * Crea el programa HiloDurmiente. Este programa genera 5 hilos en una sola
 * clase que hereda de Thread. Cada hilo debe de tener un nombre. En sus métodos
 * run (), habrá un bucle infinito que diga “Soy el hilo X y estoy trabajando”.
 * Se detendrá aleatoriamente la ejecución del hilo de 1 a 10 segundos.
 */
public class Ejercicio3 extends Thread {

	private String name;

	public Ejercicio3(String name) {
		this.name = name;
	}

	@Override
    public void run() {
        while (true) {
            System.out.println("Soy el hilo" + name + " y estoy trabajando");

            try {
                // Tiempo aleatorio entre 1 y 10 segundos
                int tiempo = (int) (Math.random() * 10 + 1); 
                
                // Pone este hilo a dormir
                Thread.sleep(tiempo * 1000L);
            } catch (InterruptedException e) {
            	// NO debería llegar aquí. Ningún otro hilo le interrumpe.
                System.out.println("El hilo" + name + " ha sido interrumpido.");
                break;
            }
        }
    }
	
	public static void main(String[] args) {
		Ejercicio3 hilo1 = new Ejercicio3("1");
		Ejercicio3 hilo2 = new Ejercicio3("2");
		Ejercicio3 hilo3 = new Ejercicio3("3");
		Ejercicio3 hilo4 = new Ejercicio3("4");
		Ejercicio3 hilo5 = new Ejercicio3("5");

		hilo1.start();
		hilo2.start();
		hilo3.start();
		hilo4.start();
		hilo5.start();
	}
}
