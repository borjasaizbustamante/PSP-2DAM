package zPSPHilos.ejercicios;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * ¿Y si queremos que el primer Hilo que termine, interrumpa al resto?
 */
public class Ejercicio3b extends Thread {

	private String name;
	private List<Ejercicio3b> hilos;

	public Ejercicio3b(String name, List<Ejercicio3b> hilos) {
		this.name = name;
		this.hilos = hilos;
	}

	@Override
	public void run() {
		System.out.println("Soy el hilo" + name + " y estoy trabajando");

		try {
			// Tiempo aleatorio entre 1 y 10 segundos
			int tiempo = (int) (Math.random() * 10 + 1);

			// Pone este hilo a dormir
			Thread.sleep(tiempo * 1000L);

			// El primer hilo que despierta y llega aqui, gana
			System.out.println("Gana el hilo" + name + " y mata al resto!");
			for (Ejercicio3b ejercicio3b : hilos) {
				if (ejercicio3b != this) {
					ejercicio3b.interrupt();
				}
			}
		} catch (InterruptedException e) {
			// Sólo se llega aqui si otro hilo te interrumpe
			System.out.println("El hilo" + name + " ha muerto...");
		}
	}

	public static void main(String[] args) {
		List<Ejercicio3b> hilos = new CopyOnWriteArrayList<>();

		hilos.add(new Ejercicio3b("1", hilos));
		hilos.add(new Ejercicio3b("2", hilos));
		hilos.add(new Ejercicio3b("3", hilos));
		hilos.add(new Ejercicio3b("4", hilos));
		hilos.add(new Ejercicio3b("5", hilos));

		for (Ejercicio3b ejercicio3b : hilos) {
			ejercicio3b.start();
		}
	}
}
