package zPSPHilos.ejercicios;

import java.awt.Image;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.TrayIcon.MessageType;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Crea el programa HiloDurmiente. Este programa genera 5 hilos en una sola
 * clase que hereda de Thread. Cada hilo debe de tener un nombre (setName ()).
 * En sus métodos run (), habrá un bucle infinito que diga “Soy el bucle X y
 * estoy trabajando”. Se detendrá aleatoriamente la ejecu-ción del hilo de 1 a
 * 10 segundos.
 */
public class Ejercicio2 extends Thread {

	public void timer() {
		// El cronometro que permite lanzar tareas cada cierto tiempo
		Timer timer = new Timer();

		// Tarea que se va a realizar con el Timer...
		TimerTask task = new TimerTask() {
			@Override
			public void run() {
				System.out.println("¡Toca estirar las piernas!");

				// Intentar mostrar notificación en la bandeja del sistema
				if (SystemTray.isSupported()) {
					mostrarNotificacion("Descanso", "¡Toca estirar las piernas!");
				} else {
					System.out.println("SystemTray no soportado");
				}
			}
		};

		// Programar la tarea después de 3seg
		long delay = 3000L;
		// timer.schedule(task, delay); // Solo muestra el mensaje UNA vez al de 3
		// segundos.
		timer.schedule(task, 0, delay); // Muestra el mensaje CADA 3 segundos.

		System.out.println("Espera 3 seg para el recordatorio...");
	}

	private void mostrarNotificacion(String titulo, String mensaje) {
		try {
			SystemTray tray = SystemTray.getSystemTray();
			Image image = Toolkit.getDefaultToolkit().createImage("icon.png");

			TrayIcon trayIcon = new TrayIcon(image, "Recordatorio");
			trayIcon.setImageAutoSize(true);
			trayIcon.setToolTip("Recordatorio de descanso");
			tray.add(trayIcon);

			trayIcon.displayMessage(titulo, mensaje, MessageType.INFO);

		} catch (Exception e) {
			System.out.println("Error " + e.getMessage());
		}
	}

	public static void main(String[] args) {
		new Ejercicio2().timer();
	}
}
