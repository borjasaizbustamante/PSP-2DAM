package org.example.hilosJoin;

public class Hilo1 extends Thread {

    public void run(){
        try {
            System.out.println("Hilo 1- Inicio!");
            this.join();
        } catch (Exception e) {
            System.out.println("Hilo 1 - Despierta!");
        }
        System.out.println("Hilo 1 - Fin!");
    }

}
