package org.example.hilosWait;

public class Hilo2 extends Thread {

    private Hilo1 hilo1 = null;

    public Hilo2(Hilo1 hilo1) {
        this.hilo1 = hilo1;
    }

    public void run(){
        synchronized (hilo1) {
            try {
                System.out.println("Hilo 2- Inicio!");
                sleep(3000);
                hilo1.notify();
            } catch (Exception e) {
                System.out.println("Hilo 2 - Despierta!");
            }
            System.out.println("Hilo 2- Fin!");
        }
    }
}
