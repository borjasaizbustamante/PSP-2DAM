package org.example.hilosWait;

public class Hilo1 extends Thread {

    public void run(){
        synchronized (this){
            try {
                System.out.println("Hilo 1- Inicio!");
                this.wait();
            } catch (InterruptedException e) {
                System.out.println("Hilo 1 - Despierta!");
            }
            System.out.println("Hilo 1 - Fin!");
        }
    }
}
