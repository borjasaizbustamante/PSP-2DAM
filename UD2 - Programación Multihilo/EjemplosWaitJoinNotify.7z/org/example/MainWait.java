package org.example;

import org.example.hilosWait.Hilo1;
import org.example.hilosWait.Hilo2;

/**
 * Generamos dos hilos. El Hilo1 espera a que el Hilo2 le haga un notify (wait)
 */
public class MainWait {
    public static void main(String[] args) {

        System.out.println("Ejemplo Wait");

        Hilo1 hilo1 = new Hilo1();
        Hilo2 hilo2 = new Hilo2(hilo1);

        hilo1.start();
        hilo2.start();
    }
}