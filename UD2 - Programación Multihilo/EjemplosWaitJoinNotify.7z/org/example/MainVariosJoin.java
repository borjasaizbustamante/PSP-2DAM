package org.example;

import org.example.hilosVariosJoin.Hilo1;
import org.example.hilosVariosJoin.Hilo2;

/**
 * Generamos dos hilos. El programa principal lanza al Hilo1 e Hilo2. Espera a que
 * la ejecución de ambos finalice por completo (join)
 */
public class MainVariosJoin {
    public static void main(String[] args) {

        System.out.println("Ejemplo Varios Join");

        Hilo1 hilo1 = new Hilo1();
        Hilo2 hilo2 = new Hilo2();

        hilo1.start();
        hilo2.start();

        try {
            hilo1.join();
            hilo2.join();
        } catch (InterruptedException e) {
            System.out.println("MAIN - Despierta!");
        }
        System.out.println("MAIN - Fin");
    }
}