package org.example.hilosVariosJoin;

public class Hilo1 extends Thread {

    public void run(){
        try {
            System.out.println("Hilo 1- Inicio!");
            sleep(3000);
        } catch (Exception e) {
            System.out.println("Hilo 1 - Despierta!");
        }
        System.out.println("Hilo 1 - Fin!");
    }

}
