package org.example.hilosVariosJoin;

public class Hilo2 extends Thread {

    public void run(){
        try {
            System.out.println("Hilo 2- Inicio!");
            sleep(3000);
        } catch (Exception e) {
            System.out.println("Hilo 2 - Despierta!");
        }
        System.out.println("Hilo 2- Fin!");
    }

}
