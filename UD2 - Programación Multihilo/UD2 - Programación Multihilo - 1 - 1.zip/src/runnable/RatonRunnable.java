package runnable;

/**
 * Esta clase tiene varios Hilos. Por tanto, necesitamos que implemente la
 * interfaz Runnable
 */
public class RatonRunnable  implements Runnable {

	private String nombre = "";
	private int tiempo = 0;

	public RatonRunnable(String nombre, int tiempo) {
		super();
		this.nombre = nombre;
		this.tiempo = tiempo;
	}

	// Cada vez que el Raton come, espera n segundos
	public void comer() {
		try {
			System.out.printf("El Raton %s empieza a comer %n", nombre);
			Thread.sleep(tiempo * 1000); // Duerme en Hilo n segundos
			System.out.printf("El Raton %s ha terminado de comer %n", nombre);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	// Cuando se ejecuta el metodo start se genera un Hilo independiente. Luego
	// cada Hilo llama a su propio run () de forma automatica
	@Override
	public void run() {
		this.comer();
	}

	public static void main(String[] args) {
		System.out.printf("Hilo Principal arrancado%n");

		RatonRunnable raton1 = new RatonRunnable("1", 4);
		RatonRunnable raton2 = new RatonRunnable("2", 2);
		RatonRunnable raton3 = new RatonRunnable("3", 5);

		// Arrancamos los Hilos, pero esto NO detiene al Hilo principal
		new Thread (raton1).start();
		new Thread (raton2).start();
		new Thread (raton3).start();

		System.out.printf("Hilo Principal terminado%n");
	}

}
