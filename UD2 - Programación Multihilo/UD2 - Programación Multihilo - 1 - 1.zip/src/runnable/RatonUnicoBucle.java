package runnable;

/**
 * Esta clase tiene varios Hilos lanzados sobre el mismo objeto
 */
public class RatonUnicoBucle implements Runnable {

	private String nombre = "";
	private int tiempo = 0;
	private int alimentoConsumido = 0;

	public RatonUnicoBucle(String nombre, int tiempo) {
		super();
		this.nombre = nombre;
		this.tiempo = tiempo;
	}

	// Cada vez que el Raton come, espera n segundos
	public void comer() {
		try {
			System.out.printf("El Raton %s empieza a comer %n", nombre);
			Thread.sleep(tiempo * 1000); // Duerme en Hilo n segundos
			alimentoConsumido ++; // NOTA: esta variable est� compartida por todos los Hilos
			System.out.printf("El Raton %s ha terminado de comer %n", nombre);
			System.out.printf("Alimento consumido: %s %n", alimentoConsumido);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	// Cuando se ejecuta el metodo start se genera un Hilo independiente. Luego
	// cada Hilo llama a su propio run () de forma automatica
	@Override
	public void run() {
		this.comer();
	}

	public static void main(String[] args) {
		System.out.printf("Hilo Principal arrancado%n");

		RatonUnicoBucle ratonUnico = new RatonUnicoBucle("1", 4);

		for (int i = 0; i < 1000; i++) {
			new Thread(ratonUnico).start();
		}
		
		System.out.printf("Hilo Principal terminado%n");
	}

}
