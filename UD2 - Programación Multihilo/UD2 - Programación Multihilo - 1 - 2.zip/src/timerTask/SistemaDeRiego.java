package timerTask;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Esta clase 'riega' de forma autom�tica
 */
public class SistemaDeRiego extends TimerTask {

	@Override
	public void run() {
		System.out.printf("Regando...%n");
	}

	public static void main(String[] args) {
		System.out.printf("Hilo Principal arrancado%n");

		// Retardo de 1 segundo, riega cada 2 segundos
		Timer temporizador = new Timer();
		temporizador.schedule(new SistemaDeRiego(), 1000, 2000);

		System.out.printf("Hilo Principal terminado%n");
	}
}

