package estructurasConcurrentes;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Resulta que palabras es totalmente segura para accesos m�ltiples
 */
public class LectorEscritorSeguro extends Thread {

	private static List<String> palabras = new CopyOnWriteArrayList <String>();

	@Override
	public void run() {
		palabras.add(new String("Nueva Palabra"));
		for (String palabra : palabras) {
			palabras.size();
		}
		System.out.println (palabras.size());
	}

	public static void main(String[] args) {
		for (int i = 0; i<100; i++)
			new LectorEscritorSeguro().start();
	}
}

