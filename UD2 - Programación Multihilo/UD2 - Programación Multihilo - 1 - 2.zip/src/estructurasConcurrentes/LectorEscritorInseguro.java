package estructurasConcurrentes;

import java.util.ArrayList;
import java.util.List;

/**
 * Resulta que palabras es totalmente insegura para accesos m�ltiples
 */
public class LectorEscritorInseguro extends Thread {

	private static List<String> palabras = new ArrayList<String>();

	@Override
	public void run() {
		palabras.add(new String("Nueva Palabra"));
		for (String palabra : palabras) {
			palabras.size();
		}
		System.out.println (palabras.size());
	}

	public static void main(String[] args) {
		for (int i = 0; i<100; i++)
			new LectorEscritorInseguro().start();
	}
}
