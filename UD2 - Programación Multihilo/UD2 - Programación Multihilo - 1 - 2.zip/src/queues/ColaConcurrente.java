package queues;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedDeque;

/**
 * Esta cola est� protegida contra hilos... 
 */
public class ColaConcurrente implements Runnable{

	// Una cola �nica para todos los Hilos
	private static Queue <Integer> cola = new ConcurrentLinkedDeque<Integer>();

	@Override
	public void run() {
		// Cargamos un 10
		cola.add(10);
		for (Integer i : cola) {
			System.out.println(i + ":");
		}
		System.out.println("Tama�o de la cola: " + cola.size());
	}
	
	public static void main(String[] args) {
		// Lanzamos 10 Hilos
		for (int i = 0; i <10; i++) {
			new Thread (new ColaConcurrente()).start();
		}
	}
}


