package queues;

import java.util.LinkedList;
import java.util.Queue;

/**
 * Esta cola no est� protegida contra hilos... 
 */
public class ColaNoConcurrente implements Runnable{

	// Una cola �nica para todos los Hilos
	private static Queue <Integer> cola = new LinkedList<Integer>();

	@Override
	public void run() {
		// Cargamos un 10
		cola.add(10);
		for (Integer i : cola) {
			System.out.println(i + ":");
		}
		System.out.println("Tama�o de la cola: " + cola.size());
	}
	
	public static void main(String[] args) {
		// Lanzamos 10 Hilos
		for (int i = 0; i <10; i++) {
			new Thread (new ColaNoConcurrente()).start();
		}
	}
}


