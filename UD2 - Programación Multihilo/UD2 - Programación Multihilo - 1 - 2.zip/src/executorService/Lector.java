package executorService;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Intercambiamos informaci�n entre hilos...
 */
public class Lector implements Callable<String> {

	@Override
	public String call() throws Exception {
		String textoLeido = "Me gustan las pelis de accion";
		Thread.sleep(1000); // A�adimos un retardo
		return textoLeido;
	}

	public static void main(String[] args) {
		try {
			// La tarea que queremos ejecutar
			Lector lector = new Lector();

			// El servicio que ejecuta las tareas
			ExecutorService executorService = Executors.newSingleThreadExecutor();

			// El resultado de la tarea
			Future<String> resultado = executorService.submit(lector);

			// �Ha terminado? 
			String texto = resultado.get();
			if (resultado.isDone()) {
				System.out.println("Resultado = " + texto);
				System.out.println("Tearea finalizada");
			} else if (resultado.isCancelled()){
				System.out.println("Tearea cancelada");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
