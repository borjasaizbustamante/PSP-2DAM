package exchanger;

import java.util.concurrent.Exchanger;

/**
 * Intercambiamos informaci�n entre hilos... 
 */
public class ProgramaPrincipal {

	public static void main(String[] args) {
		Exchanger <String> exchanger = new Exchanger <String>(); 
		new Thread (new Tarea1(exchanger)).start();
		new Thread (new Tarea2(exchanger)).start();
	}
}
