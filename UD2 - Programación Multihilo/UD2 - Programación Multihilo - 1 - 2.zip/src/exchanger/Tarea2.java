package exchanger;

import java.util.concurrent.Exchanger;

public class Tarea2 implements Runnable {
	
	private Exchanger <String> exchanger;

	public Tarea2 (Exchanger <String> exchanger) {
		super();
		this.exchanger = exchanger;
	}
	
	@Override
	public void run() {
		try {
			String mensajeRecibido = exchanger.exchange("Mensaje enviado por Tarea2");
			System.out.println ("Mensaje recibido en Tarea2: " + mensajeRecibido);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
