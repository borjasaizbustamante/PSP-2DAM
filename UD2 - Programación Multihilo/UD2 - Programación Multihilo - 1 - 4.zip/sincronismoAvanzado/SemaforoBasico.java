package sincronismoAvanzado;

import java.util.concurrent.Semaphore;

public class SemaforoBasico implements Runnable {

	Semaphore semaphore = new Semaphore(3);

	@Override
	public void run() {
		try {

			semaphore.acquire(); // �Puedo pasar?
			System.out.println("Paso1");
			Thread.sleep(1000);
			System.out.println("Paso2");
			Thread.sleep(1000);
			System.out.println("Paso3");
			Thread.sleep(1000);
			semaphore.release(); // He terminado
			
		} catch (InterruptedException e) {

		}
	}

	public static void main(String[] args) {
		SemaforoBasico semaforoBasico = new SemaforoBasico();
		for (int i = 0; i < 5; i++)
			new Thread(semaforoBasico).start();
	}
}
