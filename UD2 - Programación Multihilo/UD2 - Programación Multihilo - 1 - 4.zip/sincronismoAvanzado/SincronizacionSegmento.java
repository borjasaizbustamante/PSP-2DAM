package sincronismoAvanzado;

public class SincronizacionSegmento extends Thread {

	private int id = 0;
	private Object candado1 = new Object();
	private Object candado2 = new Object();

	public SincronizacionSegmento(int id) {
		this.id = id;
	}

	public synchronized void metodo1() {
		synchronized (candado1) {
			System.out.println("Metodo 1 del Hilo" + id + " - Inicio");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				return;
			}
			System.out.println("Metodo 1 del Hilo" + id + " - Fin");
		}
	}

	public synchronized void metodo2() {
		synchronized (candado2) {
			System.out.println("Metodo 2 del Hilo" + id + " - Inicio");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				return;
			}
			System.out.println("Metodo 2 del Hilo" + id + " - Fin");
		}
	}

	@Override
	public void run() {
		if (id == 1) {
			metodo1();
			metodo2();
		} else {
			metodo2();
			metodo1();
		}
	}

	public static void main(String[] args) {
		new SincronizacionSegmento(1).start();
		new SincronizacionSegmento(2).start();
	}
}
