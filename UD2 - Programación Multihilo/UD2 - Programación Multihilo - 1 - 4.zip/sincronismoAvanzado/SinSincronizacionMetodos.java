package sincronismoAvanzado;

public class SinSincronizacionMetodos implements Runnable {

	public void metodo1() {
		System.out.println("Metodo 1 - Inicio");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			return;
		}
		System.out.println("Metodo 1 - Fin");
	}

	public void metodo2() {
		System.out.println("Metodo 2 - Inicio");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			return;
		}
		System.out.println("Metodo 2 - Fin");
	}
	
	@Override
	public void run() {
		metodo1();
		metodo2();
	}

	public static void main(String[] args) {
		SincronizacionMetodos sincronizacionMetodos = new SincronizacionMetodos();
		new Thread (sincronizacionMetodos).start();
		new Thread (sincronizacionMetodos).start();
	}
}
