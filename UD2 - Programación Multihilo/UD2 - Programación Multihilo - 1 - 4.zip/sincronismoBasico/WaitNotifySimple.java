package sincronismoBasico;

public class WaitNotifySimple implements Runnable {
	private volatile boolean ejecutandoMetodo1 = false;

	public synchronized void metodo1() {
		for (int i = 0; i < 10; i++) {
			System.out.println("Metodo 1 - Ejecucion " + i);
			if (i == 5) {
				try {
					this.wait(); // Paramos el Hilo
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public synchronized void metodo2() {
		for (int i = 1; i < 10; i++) {
			System.out.println("Metodo 2 - Ejecucion " + i);
		}
		this.notifyAll(); // Reanuda la ejecucion del Hilo detenido
	}

	@Override
	public void run() {
		if (!ejecutandoMetodo1) {
			ejecutandoMetodo1 = true;
			metodo1();
		} else 
			metodo2();
	}

	public static void main(String[] args) {
		WaitNotifySimple waitNotifySimple = new WaitNotifySimple();
		new Thread(waitNotifySimple).start();
		new Thread(waitNotifySimple).start();
	}
}
