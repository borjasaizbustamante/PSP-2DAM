package interrupciones;

public class Interrupcion extends Thread {

	@Override
	public void run() {
		int contador = 0;
		while (true) {
			contador++;
			try {
				System.out.println(contador);
				if (contador == 5)
					this.interrupt();
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				System.out.println("- FIN -");
				return; // Finaliza el hilo
			}
		}
	}

	public static void main(String[] args) {
		new Interrupcion().start();
	}
}

