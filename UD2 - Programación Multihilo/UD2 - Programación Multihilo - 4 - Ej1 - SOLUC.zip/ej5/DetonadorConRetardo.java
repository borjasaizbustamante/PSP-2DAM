package ejerciciosHilos.ej5;

public class DetonadorConRetardo implements Runnable {

	private int contador;
	private String nombre;

	public DetonadorConRetardo(int contador, String nombre) {
		this.contador = contador;
		this.nombre = nombre;
	}

	@Override
	public void run() {
		for (int i = contador; i > 0; i--) {
            System.out.println("Hilo " + nombre + " - " + contador);
            contador++;
        }
		System.out.println("Hilo " + nombre + " - Finalizado"); 
	}
}