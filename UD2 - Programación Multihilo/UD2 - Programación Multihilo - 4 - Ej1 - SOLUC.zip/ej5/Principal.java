package ejerciciosHilos.ej5;

public class Principal {

	public static void main(String[] args) {
		DetonadorConRetardo detonadorConRetardo1 = new DetonadorConRetardo(20, "Bomba1");
		DetonadorConRetardo detonadorConRetardo2 = new DetonadorConRetardo(40, "Bomba2");
		DetonadorConRetardo detonadorConRetardo3 = new DetonadorConRetardo(50, "Bomba3");
		DetonadorConRetardo detonadorConRetardo4 = new DetonadorConRetardo(30, "Bomba4");
		
        Thread thread1 = new Thread(detonadorConRetardo1);
        Thread thread2 = new Thread(detonadorConRetardo2);
        Thread thread3 = new Thread(detonadorConRetardo3);
        Thread thread4 = new Thread(detonadorConRetardo4);
        
        thread1.start();
        thread2.start();
        thread3.start();
        thread4.start();
        
        try {
        	thread1.join();
        	thread2.join();
        	thread3.join();
        	thread4.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
 
        System.out.println("Fin del hilo principal");
	}

}
