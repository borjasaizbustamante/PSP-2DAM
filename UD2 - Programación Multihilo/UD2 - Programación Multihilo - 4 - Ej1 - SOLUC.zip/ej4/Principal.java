package ejerciciosHilos.ej4;

public class Principal {

	public static void main(String[] args) {
		Escritora escritora1 = new Escritora(true);
		Escritora escritora2 = new Escritora(false);
         
        Thread thread1 = new Thread(escritora1);
        Thread thread2 = new Thread(escritora2);
         
        thread1.start();
        thread2.start();
	}

}
