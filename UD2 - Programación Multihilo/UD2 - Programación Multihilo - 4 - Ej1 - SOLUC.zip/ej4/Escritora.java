package ejerciciosHilos.ej4;

public class Escritora implements Runnable {

	private boolean tipo;

	public Escritora(boolean tipo) {
		this.tipo = tipo;
	}

	@Override
	public void run() {
		while (true) {
			if (tipo) {
				for (int i = 1; i < 30; i++) {
					System.out.println(i);
				}
			} else {
				for (char c = 'a'; c < 'z'; c++) {
					System.out.println(c);
				}
			}
		}
	}
}