package ejerciciosHilos.ej7Base;

import java.util.Observable;

public class Tortuga extends Observable implements Runnable {

	private String nombre;

	public Tortuga(String nombre) {
		this.nombre = nombre;
	}

	public String getNombre() {
		return nombre;
	}

	@Override
	public void run() {

	}

}
