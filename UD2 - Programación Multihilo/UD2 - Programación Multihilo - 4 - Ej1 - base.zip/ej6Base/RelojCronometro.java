package ejerciciosHilos.ej6Base;

import java.util.Observable;
 
public class RelojCronometro extends Observable implements Runnable {
 
    private int horas, minutos, segundos;
 
    public RelojCronometro(int horas, int minutos, int segundos) {
        this.horas = horas;
        this.minutos = minutos;
        this.segundos = segundos;
    }
 
    @Override
    public void run() {
 
    }
}
