package com.example.RestServerExample.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.RestServerExample.dataBase.FakeDataBase;
import com.example.RestServerExample.entities.Alumno;

@RestController
public class AlumnoController {

	public AlumnoController () {
		super();
	}
	
	@GetMapping ("/alumnos")
	public List <Alumno> getAllPotatoes (){
		List <Alumno> ret = null;
		FakeDataBase fake = FakeDataBase.getInstance();
		ret = fake.getAllAlumnos();
		return ret;
	}
	
	@PostMapping ("alumno/new")
	public String addAlumno (@RequestBody Alumno alumno) {
		FakeDataBase fake = FakeDataBase.getInstance();
		fake.addAlumno(alumno);
		return "Alumno insertado";
	}
	
	
}
