package com.example.RestServerExample.dataBase;

import java.util.ArrayList;
import java.util.List;

import com.example.RestServerExample.entities.Alumno;

public class FakeDataBase {

	private static final FakeDataBase instance = null;

	private List<Alumno> alumnos = null;

	private FakeDataBase() {
		alumnos = new ArrayList<Alumno>();
		alumnos.add(defaultAlumno());
	}

	public static FakeDataBase getInstance() {
		return instance == null ? new FakeDataBase() : instance;
	}

	public void reset() {
		alumnos.clear();
		alumnos.add(defaultAlumno());
	}

	private Alumno defaultAlumno() {
		return new Alumno("Juan", "Torres");
	}

	public List<Alumno> getAllAlumnos() {
		return alumnos;
	}
	
	public void addAlumno(Alumno alumno) {
		alumnos.add(alumno);
	}

	public void deleteAlumno(Alumno alumno) {
		alumnos.remove(alumno);
	}

	public Alumno findAlumno(Alumno alumno) {
		Alumno ret = null;
		for (Alumno alum : alumnos) {
			if (alumno.equals(alum)) {
				ret = alum;
				break;
			}
		}
		return ret;
	}
}
