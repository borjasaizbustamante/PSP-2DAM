package com.example.RestServerExample.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.RestServerExample.dataBase.FakeDataBase;
import com.example.RestServerExample.entities.Alumno;

@RestController
public class AlumnoController {

	public AlumnoController () {
		super();
	}
	
	@GetMapping ("/alumnos")
	public List <Alumno> getAllPotatoes (){
		
		System.out.println ("Endpoint - /alumnos");
		
		List <Alumno> ret = null;
		FakeDataBase fake = FakeDataBase.getInstance();
		ret = fake.getAllAlumnos();
		
		System.out.println ("Answer - " + ret.size() + " items");
		return ret;
	}
	
	@GetMapping ("/alumno/find/{name}")
	public ResponseEntity<Alumno> getByName(@PathVariable String name){
		System.out.println ("Endpoint - /alumno/find/{name}");
		System.out.println ("Recived - name: " + name);
		
		Alumno ret = null;
		FakeDataBase fake = FakeDataBase.getInstance();
		List <Alumno> alumnos =  fake.getAllAlumnos();
		for (Alumno alumno : alumnos) {
			if (alumno.getNombre().equals(name)) {
				// Found!
				ret = alumno;
				break;
			}
		}
		
		System.out.println (ret == null? "Answer - not found" : "Answer - " + ret.toString());
		
		// Enviamos OK (200) y el Alumno en el cuerpo
		// ... o enviamos Not Found (404) sin nada en el cuerpo
		return ret != null? ResponseEntity.ok (ret): ResponseEntity.notFound().build();
		
	}
	
	@PostMapping ("alumno/new")
	public void addAlumno (@RequestBody Alumno alumno) {
		System.out.println ("Endpoint - alumno/new");
		System.out.println ("Recived - " + alumno.toString());
		
		FakeDataBase fake = FakeDataBase.getInstance();
		fake.addAlumno(alumno);
		System.out.println ("Answer - added");
	}
	
}
