package RestClientExcample.RestClientExcample;

import RestClientExcample.RestClientExcample.client.RestClient;

public class App {
	public static void main(String[] args) {
		try {
			new RestClient().pruebasRest();
		} catch (Exception e) {
			System.out.println("Something went wrong! " + e.getMessage());
		}
	}
}
