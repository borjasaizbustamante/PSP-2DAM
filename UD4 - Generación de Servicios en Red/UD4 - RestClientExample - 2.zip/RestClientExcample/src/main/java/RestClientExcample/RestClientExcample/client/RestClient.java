package RestClientExcample.RestClientExcample.client;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import RestClientExcample.RestClientExcample.client.entities.Alumno;

public class RestClient {

	private static final String BASE_URL = "http://localhost:8080/";
	private final HttpClient client;
	private final ObjectMapper mapper;

	public RestClient() {
		client = HttpClient.newHttpClient();
		mapper = new ObjectMapper();
	}

	// Calling to List <Alumno> getAllPotatoes () method in Server API
	// It is a GET
	// The path is /alumnos
	private List<Alumno> getAllAlumnos() throws Exception {
		URI uri = URI.create(BASE_URL + "alumnos");
		
		// The request
		HttpRequest request = HttpRequest.newBuilder().uri(uri).GET().build();

		HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

		return mapper.readValue(response.body(), new TypeReference<List<Alumno>>() {
		});
	}

	// Calling to ResponseEntity<Alumno> getByName(String name) method in Server API
	// It is a GET
	// The path is /alumno/find/{name}
	private Alumno getByName(String name) throws Exception {
		HttpRequest request = HttpRequest.newBuilder().uri(URI.create(BASE_URL + "alumno/find/" + name)).GET().build();

		HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

		if (response.statusCode() == 404)
			return null;

		return mapper.readValue(response.body(), Alumno.class);
	}

	// Calling to addAlumno (@RequestBody Alumno alumno) method in Server API
	// It is a POST 
	// The path is /alumno/new
	private void addAlumno(Alumno alumno) throws Exception {
		String json = mapper.writeValueAsString(alumno);

		HttpRequest request = HttpRequest.newBuilder().uri(URI.create(BASE_URL + "alumno/new"))
				.header("Content-Type", "application/json").POST(HttpRequest.BodyPublishers.ofString(json)).build();

		client.send(request, HttpResponse.BodyHandlers.discarding());
	}

	// Pruebas
	public void pruebasRest() throws Exception {
		System.out.println("Adding new...");
		addAlumno(new Alumno("Pepe", "Martin"));

		System.out.println("Get all...");
		List<Alumno> alumnos = getAllAlumnos();
		if (alumnos == null) {
			System.out.println("Anothing here");
		} else {
			for (Alumno alumno : alumnos) {
				System.out.println(alumno.toString());
			}
		}

		System.out.println("Finding...");
		Alumno alumno = getByName("Pepe");
		System.out.println(alumno == null ? "Not found" : alumno);
	}
}
