package tcpSocketsHilos.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	public static void main(String[] args) {

		ServerSocket serverSocket = null;
		Socket socket = null;
		int puertoServer = 49171; // Coge uno libre...

		try {
			serverSocket = new ServerSocket(puertoServer);

			while (true) {
				System.out.println("Servidor - Esperando conexiones de Clientes...");
				socket = serverSocket.accept(); // En espera...

				// Delegamos la tarea de atender al cliente a un Hilo
				System.out.println("Servidor - Intento de conexion en puerto " + puertoServer);
				Tarea tarea = new Tarea(socket);
				tarea.start();
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			// Cerramos en el orden inverso al que las hemos abierto
			System.out.println("Servidor - Cerrando conexiones...");
			try {
				serverSocket.close();
			} catch (IOException e) {
				// No importa...
			}
		}

		System.out.println("Servidor - Finalizado!");
	}
}
