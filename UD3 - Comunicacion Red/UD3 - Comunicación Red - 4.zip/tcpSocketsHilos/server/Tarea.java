package tcpSocketsHilos.server;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

/**
 * Un Servidor sencillo. Usa hilos, luego es capaz de atender infinitos
 * Clientes. No termina nunca!
 */
public class Tarea extends Thread {

	private Socket socket; 
	
	public Tarea(Socket socket) {
		this.socket = socket;
	}

	@Override
	public void run() {
		InputStream inputStream = null;
		OutputStream outputStream = null;

		try {

			System.out.println("Servidor - Intento de conexion de hilo " + this.getName());
			inputStream = socket.getInputStream();
			outputStream = socket.getOutputStream();

			// inputStream y outputStream leen y escriben bytes
			// Pero se puede enviar cualquier objeto (con la clase correcta)
			System.out.println("Servidor [" + this.getName() + "]- Cliente conectado!!");
			int mensaje = inputStream.read();

			System.out.println("Servidor [" + this.getName() + "]- Mensaje del Cliente: " + mensaje);
			int respuesta = 200;
			outputStream.write(respuesta);

			System.out.println("Servidor [" + this.getName() + "]- Mensaje de respuesta: " + respuesta);

		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			// Cerramos en el orden inverso al que las hemos abierto
			System.out.println("Servidor [" + this.getName() + "] - Cerrando conexiones...");
			try {
				outputStream.close();
			} catch (IOException e) {
				// No importa...
			}
			try {
				inputStream.close();
			} catch (IOException e) {
				// No importa...
			}
			try {
				socket.close();
			} catch (IOException e) {
				// No importa...
			}
		}
	}
}
