package ejUdp.server;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

/**
 * Un server UDP Sencillo
 */
public class Server {

	public static void main(String[] args) {

		DatagramSocket datagramSocket = null;
		DatagramPacket datagramPacketIn = null;

		int puertoServer = 49171; // Coge uno libre...

		try {
			datagramSocket = new DatagramSocket(puertoServer);

			boolean isEnd = false;
			while (!isEnd) {
				System.out.println("Servidor - Esperando conexiones de Clientes...");

				byte[] bufferLectura = new byte[64];
				datagramPacketIn = new DatagramPacket(bufferLectura, bufferLectura.length);
				datagramSocket.receive(datagramPacketIn); // En espera...

				String mensajeRecibido = new String(bufferLectura);
				mensajeRecibido = mensajeRecibido.trim();
				if ((null != mensajeRecibido) && (mensajeRecibido.equalsIgnoreCase("END"))) {
					System.out.println("Servidor - Finalizamos");
					isEnd = true;
				} else 
					System.out.println("Servidor - " + mensajeRecibido);
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			System.out.println("Servidor - Cerrando conexiones...");
			datagramSocket.close();
		}

		System.out.println("Servidor - Finalizado!");
	}
}
