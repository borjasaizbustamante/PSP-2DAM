package genericServerSocket;

import genericServerSocket.controller.MyServer;

public class Launcher {

	public static void main(String[] args) {
		try {
			new MyServer().start();
		} catch (Exception e) {
			System.out.println("Error - " + e.getMessage());
			System.out.println("The server will stop");
		}
	}

}
