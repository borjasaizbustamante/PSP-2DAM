package genericServerSocket.dataBase.entities;

public class Employee {

}
