package genericServerSocket.dataBase.dao;

/**
 * Employee data base access methods
 */
public class EmployeeDao {

	/**
	 * Returns true if the user can log in, false otherwise
	 * 
	 * @param user
	 * @param pass
	 * @return true or false
	 */
	public boolean login (String user, String pass) {
		return true;
	}
	
}
