package genericServerSocket.controller;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import genericServerSocket.controller.thread.ServerThread;

public class MyServer {

	private ServerSocket serverSocket = null;

	private static final int PORT = 5000;

	public MyServer() throws IOException {
		serverSocket = new ServerSocket(PORT);
	}

	public void start() {

		System.out.println("Server is booting...");

		System.out.println("Server ready!");
		System.out.println("Listening from port [" + PORT + "]");

		while (true) {
			Socket cliente = null;
			try {
				cliente = serverSocket.accept();
				System.out.println("New message recived...");

				new ServerThread(cliente).start();
			} catch (IOException e) {
				System.out.println("Error - " + e.getMessage());
			}
		}
	}
}
