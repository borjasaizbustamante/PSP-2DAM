package genericServerSocket.controller.messages;

/**
 * Defines a Login Message
 */
public class LoginMessage implements Message {

	private static final long serialVersionUID = -5717429713560585584L;

	public static final String TYPE = "loginMessage";
	
	private String user;
    private String pass;

	public LoginMessage(String user, String pass) {
		super();
		this.user = user;
		this.pass = pass;
	}

	@Override
	public String getType() {
		return TYPE;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

}

