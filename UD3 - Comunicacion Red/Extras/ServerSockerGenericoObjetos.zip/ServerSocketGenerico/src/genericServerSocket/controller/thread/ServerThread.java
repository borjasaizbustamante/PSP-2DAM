package genericServerSocket.controller.thread;

import java.io.ObjectInputStream;
import java.net.Socket;

import genericServerSocket.controller.handlers.LoginHandler;
import genericServerSocket.controller.messages.LoginMessage;
import genericServerSocket.controller.messages.Message;

/**
 * The thread that handles the incoming messages
 */
public class ServerThread extends Thread {

	private Socket socket;

	public ServerThread(Socket socket) {
		this.socket = socket;
	}

	@Override
	public void run() {
		ObjectInputStream objectInputStream = null;
		try {
			objectInputStream = new ObjectInputStream(socket.getInputStream());
			Message message = (Message) objectInputStream.readObject();

			switch (message.getType()) {
			case LoginMessage.TYPE:
				LoginHandler loginHandler = new LoginHandler();
				loginHandler.handle((LoginMessage) message, socket);
				break;
				
				// Add more cases for another messages... 
			}

		} catch (Exception e) {
			System.out.println("Error - " + e.getMessage());
		}
	}
}
