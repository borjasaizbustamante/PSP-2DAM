package genericServerSocket.controller.handlers;

import java.net.Socket;

/**
 * Defines how handlers are. Handlers are the classes which KNOW WHAT TO DO when
 * a certain object arrives to the Server Socket
 */
public interface MessageHandler<T> {

	/**
	 * Handles the message, generates an apropriate AnswerMessage and answers that
	 * to the client via the socket
	 * 
	 * @param message The incoming message
	 * @param client The socket
	 * @throws Exception
	 */
	public void handle(T message, Socket client) throws Exception;

}