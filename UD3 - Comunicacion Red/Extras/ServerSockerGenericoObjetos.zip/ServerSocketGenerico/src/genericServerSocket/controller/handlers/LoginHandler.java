package genericServerSocket.controller.handlers;

import java.io.ObjectOutputStream;
import java.net.Socket;

import genericServerSocket.controller.messages.AnswerMessage;
import genericServerSocket.controller.messages.LoginMessage;
import genericServerSocket.dataBase.dao.EmployeeDao;

/**
 * Defines WHAT TO DO when a LoginMessage arrives (handles it)
 */
public class LoginHandler implements MessageHandler<LoginMessage> {

	public void handle(LoginMessage message, Socket cliente) throws Exception {

		try {
			System.out.println(message.getUser() + " is trying to log in");

			// We just go to teh ORM and check the login...
			EmployeeDao employeeDao = new EmployeeDao();
			boolean ok = employeeDao.login(message.getUser(), message.getPass());

			// We prepare to answer the client
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(cliente.getOutputStream());

			// The client gets an AnswerMessage
			AnswerMessage answerMessage = new AnswerMessage();
			if (ok) {
				System.out.println("Login ok!");
				answerMessage.setText("Login ok!");
			} else {
				System.out.println("Login error!");
				answerMessage.setText("Login error!");
			}

			// DO NOTE we can answer with whatever we want. We can even create several
			// different answers for different handlers. I. E. We can create a
			// GetAllEmployeeMessageAnswer with a List of Employees inside. It works, for as
			// long as the Client knows exactly HOW is the server going to answer.

			// We send the answer
			objectOutputStream.writeObject(answerMessage);
			objectOutputStream.flush();
		} catch (Exception e) {
			System.out.println("Error - " + e.getMessage());
		}
	}
}
