package udpSockets.client;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

/**
 * Un Cliente UDP sencillo. Lanza una peticion al servidor y este le responde.
 * Cuidado con las IPs!!!
 * 
 * NOTA: Fijate en el join que fuerza al programa a esperar el fin del hilo
 */
public class SocketUDPClient extends Thread {

	public static void main(String[] args) {
		DatagramSocket datagramSocket = null;
		DatagramPacket datagramPacketIn = null;
		DatagramPacket datagramPacketOut = null;
		InetAddress inetAddress = null;

		String serverName = "localhost";
		int puertoServer = 49171;

		try {
			System.out.println("Cliente - Preparando para conectar con " + serverName + ":" + puertoServer);
			inetAddress = InetAddress.getByName(serverName); // Que otro me busque la IP...

			System.out.println("Cliente - Intento de conexion");
			datagramSocket = new DatagramSocket();

			String mensaje = "100";
			byte[] bufferEscritura = new String(mensaje).getBytes();
			datagramPacketOut = new DatagramPacket(bufferEscritura, bufferEscritura.length, inetAddress, puertoServer);
			datagramSocket.send(datagramPacketOut);

			System.out.println("Cliente - Mensaje enviado: " + mensaje);
			byte[] bufferLectura = new byte[64];
			datagramPacketIn = new DatagramPacket(bufferLectura, bufferLectura.length, inetAddress, puertoServer);
			datagramSocket.receive(datagramPacketIn);

			System.out.println("Cliente - Mensaje de respuesta: " + new String(bufferLectura));

		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			System.out.println("Cliente - Cerrando conexiones...");
			datagramSocket.close();
		}

		System.out.println("Cliente - Finalizado!");
	}
}
