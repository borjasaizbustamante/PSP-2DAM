package udpSockets.server;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

/**
 * Un server UDP Sencillo 
 */
public class Server {

	public static void main(String[] args) {

		DatagramSocket datagramSocket = null;
		DatagramPacket datagramPacketIn = null;
		DatagramPacket datagramPacketOut = null;

		int puertoServer = 49171; // Coge uno libre...

		try {
			datagramSocket = new DatagramSocket(puertoServer);

			while (true) {
				System.out.println("Servidor - Esperando conexiones de Clientes...");

				byte[] bufferLectura = new byte[64];
				datagramPacketIn = new DatagramPacket(bufferLectura, bufferLectura.length);
				datagramSocket.receive(datagramPacketIn); // En espera...

				System.out.println("Servidor - Intento de conexion en puerto " + puertoServer);

				String mensajeRecibido = new String(bufferLectura);
				System.out.println("Servidor - Mensaje recibido: " + mensajeRecibido);

				// Enviamos respuesta...
				System.out.println("Servidor - Enviando respuesta");

				String respuesta = "200";
				byte[] bufferEscritura = new String(respuesta).getBytes();
				datagramPacketOut = new DatagramPacket(bufferEscritura, bufferEscritura.length,
						datagramPacketIn.getAddress(), datagramPacketIn.getPort());
				datagramSocket.send(datagramPacketOut);
				
				System.out.println("Servidor - Mensaje enviado: " + new String (bufferEscritura));
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			System.out.println("Servidor - Cerrando conexiones...");
			datagramSocket.close();
		}

		System.out.println("Servidor - Finalizado!");
	}
}
