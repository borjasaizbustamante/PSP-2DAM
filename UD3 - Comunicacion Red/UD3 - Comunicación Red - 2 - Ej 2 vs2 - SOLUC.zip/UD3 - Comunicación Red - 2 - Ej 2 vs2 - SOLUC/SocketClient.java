package ejercicio;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class SocketClient {
	public static void main(String[] args) {

		Socket socket = null;
		InputStream inputStream = null;
		OutputStream outputStream = null;
		ObjectOutputStream objectOutputStream = null;
		ObjectInputStream objectInputStream = null;
		String ipServer = "127.0.0.1";
		int puertoServer = 49171;

		try {
			socket = new Socket(ipServer, puertoServer);
			outputStream = socket.getOutputStream();
			objectOutputStream = new ObjectOutputStream(outputStream);
			
			Persona persona = new Persona("111111111E", "Juan", "Perez", new SimpleDateFormat("dd/MM/yyyy").parse("12/12/2012"));
			objectOutputStream.writeObject(persona);
			
			inputStream = socket.getInputStream();
			objectInputStream = new ObjectInputStream(inputStream);
			persona = (Persona) objectInputStream.readObject();

			System.out.println("Cliente - Mensaje de respuesta: " + persona.getNombre());

		} catch (IOException | ClassNotFoundException | ParseException ioe) {
			ioe.printStackTrace();
		} finally {
			try {
				if (null != outputStream)
					outputStream.close();
			} catch (IOException e) {
				// No importa...
			}
			try {
				if (null != inputStream)
					inputStream.close();
			} catch (IOException e) {
				// No importa...
			}
			try {
				if (null != socket)
					socket.close();
			} catch (IOException e) {
				// No importa...
			}
		}
	}
}
