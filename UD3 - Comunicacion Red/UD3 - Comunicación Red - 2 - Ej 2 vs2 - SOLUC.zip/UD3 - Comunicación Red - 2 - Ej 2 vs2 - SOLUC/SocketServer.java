package ejercicio;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class SocketServer {
	public static void main(String[] args) {

		ServerSocket serverSocket = null;
		Socket socket = null;
		InputStream inputStream = null;
		OutputStream outputStream = null;
		ObjectOutputStream objectOutputStream = null;
		ObjectInputStream objectInputStream = null;
		int puertoServer = 49171; // Coge uno libre...

		while (true) {
			try {
				serverSocket = new ServerSocket(puertoServer);
				socket = serverSocket.accept(); // En espera...
				inputStream = socket.getInputStream();

				objectInputStream = new ObjectInputStream(inputStream);
				Persona persona = (Persona) objectInputStream.readObject();

				System.out.println("Server - Recibido: " + persona.getNombre());
				
				outputStream = socket.getOutputStream();
				
				if (persona.getNombre().equals("Juan")) {
					persona = new Persona("111111111E", "Padre de Juan", "Perez", new SimpleDateFormat("dd/MM/yyyy").parse("12/12/2012"));
				} else {
					persona = new Persona();
				}
				
				outputStream = socket.getOutputStream();
				objectOutputStream = new ObjectOutputStream(outputStream);
				objectOutputStream.writeObject(persona);

			} catch (IOException | ClassNotFoundException | ParseException ioe) {
				ioe.printStackTrace();
			} finally {
				try {
					if (null != outputStream)
						outputStream.close();
				} catch (IOException e) {
					// No importa...
				}
				try {
					if (null != inputStream)
						inputStream.close();
				} catch (IOException e) {
					// No importa...
				}
				try {
					if (null != socket)
						socket.close();
				} catch (IOException e) {
					// No importa...
				}
				try {
					if (null != serverSocket)
						serverSocket.close();
				} catch (IOException e) {
					// No importa...
				}
			}
		}
	}
}
