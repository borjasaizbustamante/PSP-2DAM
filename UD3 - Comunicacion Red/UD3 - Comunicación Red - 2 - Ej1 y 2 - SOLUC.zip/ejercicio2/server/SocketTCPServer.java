package ejTcp.ejercicio2.server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;
import java.util.GregorianCalendar;

import ejTcp.ejercicio2.PersonaBean;

/**
 * Crea un programa Cliente que le pase al Servidor un objeto tipo Persona. El
 * Servidor eva-luará si la Persona se llama “Juan”, y si es así, le responderá
 * con otro objeto Persona con los datos de su padre o madre. Si no, responderá
 * con un objeto nulo.
 */
public class SocketTCPServer {

	public static void main(String[] args) {

		ServerSocket serverSocket = null;
		Socket socket = null;
		ObjectInputStream objectInputStream = null;
		ObjectOutputStream objectOutputStream = null;
		int puertoServer = 49171; // Coge uno libre...

		try {
			System.out.println("Servidor - Esperando conexiones de Clientes...");
			serverSocket = new ServerSocket(puertoServer);

			while (true) {
				socket = serverSocket.accept(); // En espera...

				System.out.println("Servidor - Intento de conexion en puerto " + puertoServer);
				objectInputStream = new ObjectInputStream(socket.getInputStream());
				
				System.out.println("Servidor - Cliente conectado!!");
				PersonaBean personaEnviada = (PersonaBean) objectInputStream.readObject();

				System.out.println("Servidor - Persona recibida del Cliente: " + personaEnviada.toString());

				PersonaBean respuesta = null;
				if ((null != personaEnviada) && (null != personaEnviada.getNombre())
						&& (personaEnviada.getNombre().equalsIgnoreCase("Juan"))) {

					respuesta = new PersonaBean();
					respuesta.setNif("98765432J");
					respuesta.setNombre("Esteban");
					respuesta.setApellido("Torres");
					respuesta.setFechaNacimiento(toDate(2000, 6, 8));
				}

				objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
				objectOutputStream.writeObject(respuesta);
				objectOutputStream.flush();
				
				System.out.println("Cliente - Persona enviada: " + respuesta.toString());

				System.out.println("Servidor - Cerrando conexiones con cliente...");
				if (null != objectOutputStream)
					objectOutputStream.close();

				if (null != objectInputStream)
					objectInputStream.close();

				if (null != socket)
					socket.close();
			}
		} catch (IOException | ClassNotFoundException ioe) {
			ioe.printStackTrace();
		} finally {
			// Cerramos en el orden inverso al que las hemos abierto
			System.out.println("Servidor - Cerrando conexiones...");

			try {
				serverSocket.close();
			} catch (IOException e) {
				// No importa...
			}
		}

		System.out.println("Servidor - Finalizado!");
	}
	
    private static Date toDate (int ano, int mes, int dia) {
        GregorianCalendar gregCal = new GregorianCalendar(ano, mes - 1, dia);
        return (new Date(gregCal.getTimeInMillis()));
    }
}
