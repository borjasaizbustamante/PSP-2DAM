package ejTcp.ejercicio2.client;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Date;
import java.util.GregorianCalendar;

import ejTcp.ejercicio2.PersonaBean;

/**
 * Crea un programa Cliente que le pase al Servidor un objeto tipo Persona. El
 * Servidor evaluará si la Persona se llama “Juan”, y si es así, le responderá
 * con otro objeto Persona con los datos de su padre o madre. Si no, responderá
 * con un objeto nulo.
 */
public class SocketTCPClient {

	public static void main(String[] args) {

		Socket socket = null;
		ObjectInputStream objectInputStream = null;
		ObjectOutputStream objectOutputStream = null;
		String ipServer = "127.0.0.1";
		int puertoServer = 49171;

		try {
			
			// Cliente que vamos a enviar...
			PersonaBean personaBean = new PersonaBean();
			personaBean.setNif("12345678X");
			personaBean.setNombre("Juan");
			personaBean.setApellido("Torres");
			personaBean.setFechaNacimiento(toDate(2000, 6, 8));
            
			System.out.println("Cliente - Preparando para conectar con " + ipServer + ":" + puertoServer);
			socket = new Socket(ipServer, puertoServer);

			System.out.println("Cliente - Intento de conexion");
			objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
			objectOutputStream.writeObject(personaBean);
			objectOutputStream.flush();
			
			System.out.println("Cliente - Persona enviada: " + personaBean.toString());
			objectInputStream = new ObjectInputStream(socket.getInputStream());
			PersonaBean respuesta = (PersonaBean) objectInputStream.readObject();

			System.out.println("Cliente - Persona recibida: " + respuesta.toString());

		} catch (IOException | ClassNotFoundException ioe) {
			ioe.printStackTrace();
		} finally {
			// Cerramos en el orden inverso al que las hemos abierto
			System.out.println("Cliente - Cerrando conexiones...");
			try {
				if (null != objectInputStream)
					objectInputStream.close();
			} catch (IOException e) {
				// No importa...
			}
			try {
				if (null != objectOutputStream)
					objectOutputStream.close();
			} catch (IOException e) {
				// No importa...
			}
			try {
				if (null != socket)
					socket.close();
			} catch (IOException e) {
				// No importa...
			}
		}

		System.out.println("Cliente - Finalizado!");
	}
	
    private static Date toDate (int ano, int mes, int dia) {
        GregorianCalendar gregCal = new GregorianCalendar(ano, mes - 1, dia);
        return (new Date(gregCal.getTimeInMillis()));
    }
}
