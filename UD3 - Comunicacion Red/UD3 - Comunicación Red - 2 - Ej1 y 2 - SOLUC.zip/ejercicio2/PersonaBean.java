package ejTcp.ejercicio2;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

/**
 * Crea un programa Cliente que le pase al Servidor un objeto tipo Persona. El
 * Servidor eva-luará si la Persona se llama “Juan”, y si es así, le responderá
 * con otro objeto Persona con los datos de su padre o madre. Si no, responderá
 * con un objeto nulo.
 */
public class PersonaBean implements Serializable {

	private static final long serialVersionUID = 1646384092668845627L;
	
    private String nif;
    private String nombre;
    private String apellido;
    private Date fechaNacimiento;

    public PersonaBean() {
        super();
    }
    
    public String getNif() {
        return nif;
    }

    public void setNif(String nif) {
        this.nif = nif;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

	@Override
	public int hashCode() {
		return Objects.hash(apellido, fechaNacimiento, nif, nombre);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PersonaBean other = (PersonaBean) obj;
		return Objects.equals(apellido, other.apellido) && Objects.equals(fechaNacimiento, other.fechaNacimiento)
				&& Objects.equals(nif, other.nif) && Objects.equals(nombre, other.nombre);
	}

	@Override
	public String toString() {
		return "PersonaBean [nif=" + nif + ", nombre=" + nombre + ", apellido=" + apellido + ", fechaNacimiento="
				+ fechaNacimiento + "]";
	}
}
