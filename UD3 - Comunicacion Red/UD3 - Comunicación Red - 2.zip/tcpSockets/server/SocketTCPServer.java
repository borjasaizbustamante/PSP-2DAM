package tcpSockets.server;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Un Servidor sencillo. Espera a que le lleguen peticiones del Cliente,
 * responde y termina. Obviamente, los servidores NO deberían terminar nunca...
 */
public class SocketTCPServer {

	public static void main(String[] args) {

		ServerSocket serverSocket = null;
		Socket socket = null;
		InputStream inputStream = null;
		OutputStream outputStream = null;
		int puertoServer = 49171; // Coge uno libre...

		try {
			System.out.println("Servidor - Esperando conexiones de Clientes...");
			serverSocket = new ServerSocket(puertoServer);
			socket = serverSocket.accept(); // En espera...

			System.out.println("Servidor - Intento de conexion en puerto " + puertoServer);
			inputStream = socket.getInputStream();
			outputStream = socket.getOutputStream();

			// inputStream y outputStream leen y escriben bytes
			// Pero se puede enviar cualquier objeto (con la clase correcta)
			System.out.println("Servidor - Cliente conectado!!");
			int mensaje = inputStream.read();

			System.out.println("Servidor - Mensaje del Cliente: " + mensaje);
			int respuesta = 200;
			outputStream.write(respuesta);

			System.out.println("Servidor - Mensaje de respuesta: " + respuesta);

		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			// Cerramos en el orden inverso al que las hemos abierto
			System.out.println("Servidor - Cerrando conexiones...");
			try {
				outputStream.close();
			} catch (IOException e) {
				// No importa...
			}
			try {
				inputStream.close();
			} catch (IOException e) {
				// No importa...
			}
			try {
				socket.close();
			} catch (IOException e) {
				// No importa...
			}
			try {
				serverSocket.close();
			} catch (IOException e) {
				// No importa...
			}
		}

		System.out.println("Servidor - Finalizado!");
	}

}
