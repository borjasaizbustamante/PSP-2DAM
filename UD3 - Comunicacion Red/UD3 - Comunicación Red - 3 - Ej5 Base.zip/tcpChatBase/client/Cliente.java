package tcpChatBase.client;

/**
 * Gestiona un socket, del que obtiene un dataOutputStream y un dataInputStream.
 * El dataOutputStream (envio) se gestiona directamente. El dataInputStream
 * (escucha) se gestiona en el hilo HiloEscucha.
 */
public class Cliente {

	// TODO Something to do here...
	
}
