package tcpChatBase.server;

/**
 * Gestiona un ServerSocket y la lista de OutputStreams
 */
public class Servidor extends Thread {
	
	// TODO Something to do here...
	
}