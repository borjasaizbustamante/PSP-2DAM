package es;

/**
 * Esta clase simula un proceso principal que, ejecuta al proceso secundario
 * (exec) y se queda esperando a que termine (waitFor). Se recoge el valor de
 * finalizaci�n y se eval�a para tomar una decisi�n.
 */
public class ProcesoPrincipal {

	public static void main(String[] args) {
		System.out.println("Ejecutamos el proceso secundario....");

		try {
			
			// Proceso que queremos lanzar
			String [] processInfo = {"java", "es.ProcesoSecundario"};
			Process process = Runtime.getRuntime().exec(processInfo);
			
			// Esperamos a que termine (Se bloquea la ejecuci�n del proceso principal)
			int valorRetorno = process.waitFor();
			
			// �Qu� ha pasado con el proceso secundario?
			if (valorRetorno == 0) {
				System.out.println("Proceso secundario finalizado con �xito");
			} else {
				System.out.println("El proceso secundario ha fallado");
				System.out.println("C�digo de error: " + valorRetorno);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
