package processOne;

public class SecondaryProcess {

	public static void main(String[] args) {
		System.out.println("Secondary process running...");

		// The process do some stuff, but something goes wrong...

		// System.exit() ends teh JVM instances in execution. If exit (0) then it ended
		// OK. If not, there was an error. The number is the error code, which we decide.

		System.exit(103);
	}
}
