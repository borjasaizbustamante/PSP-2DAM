package processOne;

import java.io.File;

public class PrimaryProcess2 {

	public static void main(String[] args) {
		System.out.println("Primary process running...");
		System.out.println("Launching secondary process...");
		
		try {
			// We prepare the process...
			String[] processInfo = {"java", "es.ProcesoSecundario"};
			Runtime runtime = Runtime.getRuntime();
			Process process = runtime.exec(processInfo);

			// The primary process waits until secondary process ends
			int valorRetorno = process.waitFor();
			if (valorRetorno == 0) {
				System.out.println("Secondary process finsished!!");
			} else {
				System.out.println("Secondary process finsished with errors: " + valorRetorno);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
