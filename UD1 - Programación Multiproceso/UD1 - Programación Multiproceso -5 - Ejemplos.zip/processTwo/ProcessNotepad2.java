package processTwo;

public class ProcessNotepad2 {

	public static void main(String[] args) {
		System.out.println("Launching notepad...");

		String[] processInfo = { "notepad" };
		try {
			Process process = Runtime.getRuntime().exec(processInfo);
			
			long pid = process.pid();
			System.out.println("Process PID: " + pid);
			
			// The primary process waits until secondary process ends
			int valorRetorno = process.waitFor();
			System.out.println("Secondary process finsished! - " + valorRetorno);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
