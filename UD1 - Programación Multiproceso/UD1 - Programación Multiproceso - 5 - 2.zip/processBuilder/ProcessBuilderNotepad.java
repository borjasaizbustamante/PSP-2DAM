package processBuilder;

import java.io.IOException;
import java.util.Map;

/**
 * Esta clase lanza el Notepad de Windows
 */
public class ProcessBuilderNotepad {

	public static void main(String[] args) {
		System.out.println("Vamos a lanzar el Notepad...");
		
		String infoProceso = "Notepad.exe";
		try {
			
			// Preparamos el Proceso
			ProcessBuilder processBuilder = new ProcessBuilder (infoProceso);
			
			// Obtenemos informacion del Proceso
			Map <String, String> environment = processBuilder.environment();
			System.out.println("Numero de Procesadores: " + environment.get("NUMBER_OF_PROCESSORS"));
			
			// Ejecutamos el Proceso
			Process proceso = processBuilder.start();
			
			// Esperamos a que finalice el proceso. Cogemos el codigo de retorno
			int codigoRetorno = proceso.waitFor();
			System.out.println("Fin del Proceso con el codigo " + codigoRetorno);
			
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}
	}
}

