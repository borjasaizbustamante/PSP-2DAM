package runtime;

import java.io.IOException;

/**
 * Esta clase lanza el Notepad de Windows
 */
public class ExecNotepad {

	public static void main(String[] args) {
		System.out.println("Vamos a lanzar el Notepad...");
		
		String [] infoProceso = {"Notepad.exe"};
		
		try {
			// Ejecutamos el nuevo Proceso
			Process proceso = Runtime.getRuntime().exec(infoProceso);
			
			// Esperamos a que finalice el proceso. Cogemos el codigo de retorno
			int codigoRetorno = proceso.waitFor();
			
			System.out.println("Fin del Proceso con el codigo " + codigoRetorno);
			
		} catch (IOException | InterruptedException e) {
			e.printStackTrace();
		}
	}
}

