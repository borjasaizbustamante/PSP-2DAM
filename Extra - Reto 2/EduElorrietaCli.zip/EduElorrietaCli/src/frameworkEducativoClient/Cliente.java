package frameworkEducativoClient;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Scanner;

/**
 * Cliente de prueba
 */
public class Cliente {

	private Scanner scanner = null;

	public Cliente() {
		scanner = new Scanner(System.in);
	}

	public void doSend() {

		DataOutputStream dataOutputStream = null;
		ObjectInputStream objectInputStream = null;

		try {
			Socket socket = new Socket("localhost", 8081);

			System.out.println("Introduce opción: ");
			int opcion = scanner.nextInt();

			// Enviamos la opción al server...
			OutputStream outputStream = socket.getOutputStream();
			dataOutputStream = new DataOutputStream(outputStream);
			dataOutputStream.writeInt(opcion);

			// Leemos la respuesta
			InputStream inputStream = socket.getInputStream();
			objectInputStream = new ObjectInputStream(inputStream);
			String respuesta = (String) objectInputStream.readObject();

			System.out.println("Respuesta del servidor:");
			System.out.println(respuesta);

			socket.close();
			scanner.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				if (null != objectInputStream) {
					objectInputStream.close();
				}
			} catch (Exception e) {

			}
			try {
				if (null != dataOutputStream) {
					dataOutputStream.close();
				}
			} catch (Exception e) {

			}
		}
	}

	public static void main(String[] args) {
		Cliente cliente = new Cliente();
		cliente.doSend();
	}

}
