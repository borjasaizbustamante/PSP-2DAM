package frameworkEducativo;

import java.io.IOException;
import java.net.ServerSocket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import frameworkEducativo.serverSockets.HiloServerSocket;

@SpringBootApplication
public class ServerWebApplication {

	/** 
	 * Este main se lanza solo al arrancar el Springboot. Lo hace por la 
	 * etiqueta @SpringBootApplication, y por cómo funciona la arquitectura
	 * de Spring. 
	 * 
	 * No le des más vueltas.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		
		// Esto arranca el server, y de paso, se prepara todos los REST 
		// que hay en los paquetes-hijo de frameworkEducativo
		SpringApplication.run(ServerWebApplication.class, args);
		
		System.out.println("Server Socket inicializándose...");
		
		// .. pero a demás, queremos que atienda los Sockets
		try {
			
			@SuppressWarnings("resource")
			ServerSocket socketServer = new ServerSocket(8081);
			
			System.out.println("Server Socket inicializado en el puerto 8081");
			while (true) {
				HiloServerSocket hilo = new HiloServerSocket(socketServer.accept());
				hilo.start();
			}
			
			// Cada vez que le llega una petición se genera un HiloServerSocket para 
			// tratar esa petición. Se le pasa un socket, y ServerWebApplication
			// vuelve a estado reposo (accept). 
			
		} catch (IOException e) {
			System.out.println("Algo ha ido mal en el Server Socket...");
			System.out.println("Finalizando el Server Socket...");
			e.printStackTrace();
		}
	}
}
