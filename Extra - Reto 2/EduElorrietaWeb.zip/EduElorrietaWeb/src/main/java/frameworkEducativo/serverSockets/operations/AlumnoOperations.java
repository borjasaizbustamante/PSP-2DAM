package frameworkEducativo.serverSockets.operations;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import frameworkEducativo.ddbb.dao.AlumnosDao;
import frameworkEducativo.ddbb.entity.Alumno;

public class AlumnoOperations {

	/**
	 * Operación que retorna todos los alumnos por el socket
	 * 
	 * @param objectOutputStream
	 */
	public void operacionGetAllAlumnos(ObjectOutputStream objectOutputStream) {
		// Aquí iría la lógica para obtener del ORM todos los alumnos
		
		// Date cuenta que esta clase estaría haciendo lo mismo que 
		// AlumnosController, y luego accedería al ORM
 		
		// Aquí llamaríamos al AlumnoDao, etc.
		AlumnosDao alumnosDao = new AlumnosDao ();
		List <Alumno> alumnos = alumnosDao.getAllAlumnos ();
		
		// Lo que cambia es al respuesta, que sería un JSON
		
    	Gson gson = new GsonBuilder().setPrettyPrinting().excludeFieldsWithoutExposeAnnotation().create();
    	String ciclosJson = gson.toJson(alumnos);
   
		try {
			objectOutputStream.writeObject(ciclosJson);
			objectOutputStream.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
