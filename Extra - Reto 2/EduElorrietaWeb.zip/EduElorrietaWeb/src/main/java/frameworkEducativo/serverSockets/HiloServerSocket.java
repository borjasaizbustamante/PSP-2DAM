package frameworkEducativo.serverSockets;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;

import frameworkEducativo.serverSockets.operations.AlumnoOperations;

/**
 * Hilo que gestiona cada una de las peticiones que llega al Server Socket
 */
public class HiloServerSocket extends Thread {
	
	private Socket socket;
	
	/**
	 * Contructor de HiloServerSocket
	 * 
	 * @param socket El Socket por el que se comunica
	 */
	public HiloServerSocket(Socket socket) {
		this.socket = socket;
	}
	
	/**
	 * Run
	 */
	public void run() {
		
		System.out.println("Cliente conectado: " + socket.getInetAddress().getHostAddress());
		
		try {
			
			// Preparamos los streams para comunicarnos por el socket
			InputStream inputStream = this.socket.getInputStream();
			DataInputStream dataInputStream = new DataInputStream(inputStream);
			
			OutputStream outputStream = this.socket.getOutputStream();
			ObjectOutputStream objectOutputStream = new ObjectOutputStream (outputStream);
			
			// Nos dicen el tipo de operación que quieren ejecutar.
			// Esto es un ejemplo: si tienes que pasarle parámetros
			// (el login y pass para comprobar un login, por ejemplo)
			// entonces mejor pasar JSON en lugar de un int 
			int operacion = dataInputStream.readInt();
			
			System.out.println("Operación a realizar: " + operacion);
			switch (operacion) {
			case 1:
				operacionGetAllAlumnos(objectOutputStream);
				break;
			}
			
			dataInputStream.close();
			socket.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	/**
	 * Operación que retorna todos los alumnos por el socket
	 * 
	 * @param objectOutputStream
	 */
	private void operacionGetAllAlumnos(ObjectOutputStream objectOutputStream) {
		AlumnoOperations alumnoOperations = new AlumnoOperations ();
		alumnoOperations.operacionGetAllAlumnos (objectOutputStream);
	}

}
