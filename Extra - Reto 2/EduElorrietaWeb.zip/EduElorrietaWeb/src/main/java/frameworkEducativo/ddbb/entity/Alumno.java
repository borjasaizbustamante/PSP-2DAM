package frameworkEducativo.ddbb.entity;

public class Alumno {

}
