package frameworkEducativo.ddbb.dao;

import java.util.List;

import frameworkEducativo.ddbb.entity.Alumno;

public class AlumnosDao {

	public List <Alumno> getAllAlumnos() {
		System.out.println("Accediendo a la BBDD..." );
		return null;
	}

}
