package frameworkEducativo.controller;

import java.util.List;

import frameworkEducativo.ddbb.dao.AlumnosDao;
import frameworkEducativo.ddbb.entity.Alumno;

/**
 * Controlador para Alumnos
 */
public class AlumnosCotroller {

	/**
	 * Retorna todos los alumnos
	 * 
	 * @return todos los alumnos o null
	 */
	public List <Alumno> getAllAlumnos (){
		System.out.println("Accediendo al controller..." );
		
		// Aquí llamaríamos al AlumnoDao, etc.
		AlumnosDao alumnosDao = new AlumnosDao ();
		List <Alumno> alumnos = alumnosDao.getAllAlumnos ();
		
		return alumnos;
	}
}
