package frameworkEducativo.restApi;


import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import frameworkEducativo.controller.AlumnosCotroller;
import frameworkEducativo.ddbb.entity.Alumno;

@RestController
@RequestMapping("/alumnos")
public class AlumnosRest {

    public AlumnosRest() {}

    @GetMapping ("/getAll")
    public String listar() {
    	System.out.println("Map - /alumnos, Metodo GET lanzado" );
    	
    	// Llamamos al Cotrolador para que haga cosas...
    	AlumnosCotroller alumnosCotroller = new AlumnosCotroller ();
    	alumnosCotroller.getAllAlumnos();
    	
        return "hola";
    }

    @PostMapping ("/save")
    public String guardar(@RequestBody Alumno alumno) {
    	System.out.println("Map - /save, Metodo POST lanzado" );
    	
    	// Llamamos al Cotrolador para que haga cosas...
    	
        return "hola";
    }

    @DeleteMapping("/delete/{id}")
    public void eliminar(@PathVariable Long id) {
    	System.out.println("Map - /delete, Metodo DELETE lanzado" );
    	
    	// Llamamos al Cotrolador para que haga cosas...
    }
}
